function love.draw()
    love.graphics.print("Hello World", 400, 300)
end

-- Define the player's initial position and speed
local player = { x = 100, y = 100, speed = 200 }

-- Define the initial position of a coin
local coin = { x = 400, y = 300 }

-- Keep track of the score
local score = 0

function love.load()
    -- Load any game assets here if needed
end

function love.update(dt)
    -- Player movement
    if love.keyboard.isDown("left") then
        player.x = player.x - player.speed * dt
    elseif love.keyboard.isDown("right") then
        player.x = player.x + player.speed * dt
    end

    if love.keyboard.isDown("up") then
        player.y = player.y - player.speed * dt
    elseif love.keyboard.isDown("down") then
        player.y = player.y + player.speed * dt
    end

    -- Check for collisions with the coin
    if CheckCollision(player.x, player.y, 32, 32, coin.x, coin.y, 32, 32) then
        score = score + 1
        -- Move the coin to a new random position
        coin.x = math.random(0, love.graphics.getWidth() - 32)
        coin.y = math.random(0, love.graphics.getHeight() - 32)
    end
end

function love.draw()
    -- Draw the player character
    love.graphics.rectangle("fill", player.x, player.y, 32, 32)

    -- Draw the coin
    love.graphics.rectangle("fill", coin.x, coin.y, 32, 32)

    -- Display the score
    love.graphics.print("Score: " .. score, 10, 10)
end

-- Check if two rectangles are colliding
function CheckCollision(x1, y1, w1, h1, x2, y2, w2, h2)
    return x1 < x2 + w2 and
           x2 < x1 + w1 and
           y1 < y2 + h2 and
           y2 < y1 + h1
end
